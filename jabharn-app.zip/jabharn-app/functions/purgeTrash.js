/**
 * PHASE 2 — deploy only once FEATURE_FLAGS.SHARE_ENABLED is turned on and
 * a real Firebase project/Firestore is live. Until then this file just
 * sits here, ready.
 *
 * Runs once a day. Permanently deletes any trip/party whose deletedAt is
 * older than RETENTION_DAYS. This exists as a server-side safety net —
 * CloudRepository.purgeExpiredTrash() is a client no-op on purpose, since
 * relying on a client to ever reopen the app to clean up isn't reliable.
 *
 * Requires: firebase-functions v2, firebase-admin
 *   npm install firebase-functions firebase-admin
 * Deploy with: firebase deploy --only functions:purgeTrash
 */
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const RETENTION_DAYS = 30;
const COLLECTIONS = ["trips", "parties"];

exports.purgeTrash = onSchedule("every 24 hours", async () => {
  const cutoffIso = new Date(
    Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000
  ).toISOString();

  for (const collectionName of COLLECTIONS) {
    const snap = await db
      .collection(collectionName)
      .where("deletedAt", "<=", cutoffIso)
      .get();

    if (snap.empty) continue;

    const batch = db.batch();
    snap.forEach((docSnap) => batch.delete(docSnap.ref));
    await batch.commit();

    console.log(
      `[purgeTrash] ${collectionName}: permanently removed ${snap.size} item(s) older than ${RETENTION_DAYS} days`
    );
  }
});
