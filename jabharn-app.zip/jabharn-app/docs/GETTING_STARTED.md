# Getting started with Jabharn

This repo is a **starting point**, not a finished app. Here's exactly what
exists today and what to do next, in order.

## What's already here

- `reference/web-prototype/jabharn.jsx` — a fully working React web version
  of the app (bill splitting, trips, meals, accommodation, trash, i18n
  strings implied in the UI). This is the **source of truth for features
  and logic** — the calculation code (splitting bills, simplifying debts)
  can be copied almost as-is into React Native, since it's plain JavaScript
  with no web-only APIs.
- `reference/web-prototype/jabharn_offline.html` — the same app compiled
  into one offline-runnable HTML file, useful just to click through the
  intended behavior before rebuilding it in React Native.
- `src/data/` — a repository layer (`LocalRepository` for phase 1,
  `CloudRepository` stubbed for phase 2, both behind one shared interface).
- `src/auth/AuthService.ts` — Google / email-link / guest sign-in, active
  from phase 1.
- `src/i18n/` — Thai/English strings and setup, active from phase 1.
- `App.tsx` — bare entry point proving i18n + auth wiring works. No real
  screens yet.

## What to do next, in order

1. **Install dependencies** (once you have a terminal — either locally or
   through Claude Code on the web's environment):
   ```bash
   npm install
   ```
2. **Set up a Firebase project** (free): console.firebase.google.com →
   create project → enable Authentication (Google, Email link, Anonymous
   providers) → create a Firestore database (test mode is fine for now).
   Copy the config values into `src/firebase/firebaseConfig.ts`.
3. **Run the app** and confirm the placeholder screen loads:
   ```bash
   npx expo start
   ```
   Scan the QR code with the **Expo Go** app on your phone.
4. **Build the real screens**, one at a time, translating from
   `reference/web-prototype/jabharn.jsx`:
   - `Home` — list of trips/parties, create buttons, search, storage bar
   - `NewTripForm` / `TripDetail` (with Accommodation / Meals / Report tabs)
   - `NewPartyForm` / `PartyDetail`
   - `Trash` screen (new — call `repo.listTrash()`, `repo.restore()`,
     show `trash.expiresIn` countdown using `deletedAt` + 30 days)

   Translation notes:
   - `div` / `span` → `View` / `Text`
   - `input` → `TextInput`
   - `button` → `TouchableOpacity` or `Pressable`
   - inline `<style>` CSS → `StyleSheet.create({...})`
   - `window.storage.get/set` calls → `createTripRepository()` /
     `createPartyRepository()` from `src/data/repositoryFactory.ts`
   - hardcoded Thai strings → `t("...")` using the keys already defined in
     `src/i18n/locales/th.json` / `en.json` (add more keys as needed)
5. **Wire up navigation** between screens — add `@react-navigation/native`
   once you're ready (not included yet, to keep the starting point simple).
6. **Test on your own phone** continuously via Expo Go as you go — no need
   to wait until the app is "done."
7. **When ready for real users**: follow the Play Store steps in the main
   `README.md` (Google Play Console signup, closed testing requirement,
   `eas build`).

## If you're using Claude Code on the web

Good first prompts to try once this repo is connected:
- *"Explain what src/data/repositoryFactory.ts does and why it's designed this way."*
- *"Build the Home screen in React Native, based on the Home component in reference/web-prototype/jabharn.jsx. Use the repositories from src/data instead of window.storage."*
- *"Add a Trash screen that lists soft-deleted trips and parties with a restore button."*

Ask it to explain each change as it makes them — that's the fastest way to
actually learn React Native while building this, rather than just getting
a black box handed to you.
