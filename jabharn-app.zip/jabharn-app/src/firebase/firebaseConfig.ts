import { initializeApp } from "firebase/app";

// Replace with your real project's values (Firebase console > Project
// settings > General > Your apps). Safe to commit — these are public
// client identifiers, not secrets. Actual access control lives in
// firestore.rules, not here.
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

export const firebaseApp = initializeApp(firebaseConfig);
