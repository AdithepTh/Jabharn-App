/**
 * Auth is active from Phase 1 — it doesn't depend on FEATURE_FLAGS.SHARE_ENABLED
 * at all. Having every user (even guests) carry a stable Firebase uid from
 * day one means Phase 2 (linking a device's local trips to an account, then
 * to the cloud) has no messy migration to do later.
 *
 * Requires: npm install firebase
 */
import {
  getAuth,
  onAuthStateChanged,
  signInAnonymously,
  signInWithCredential,
  GoogleAuthProvider,
  EmailAuthProvider,
  sendSignInLinkToEmail,
  isSignInWithEmailLink,
  signInWithEmailLink,
  linkWithCredential,
  signOut as firebaseSignOut,
  type User,
} from "firebase/auth";
import { firebaseApp } from "../firebase/firebaseConfig";

const auth = getAuth(firebaseApp);

export const EMAIL_LINK_STORAGE_KEY = "jabharn:pendingEmailForSignIn";

export function getCurrentUserId(): string {
  const u = auth.currentUser;
  if (!u) {
    throw new Error(
      "No signed-in user yet. Call ensureSignedIn() once at app startup before touching any repository."
    );
  }
  return u.uid;
}

export function onAuthChange(cb: (user: User | null) => void) {
  return onAuthStateChanged(auth, cb);
}

/**
 * Call once at app startup. If nobody has explicitly signed in yet, this
 * transparently signs the device in as a guest (Firebase Anonymous Auth)
 * so there is always a stable uid to attach data to — the user never sees
 * a "guest" concept unless they open a settings screen that offers to
 * "save your data with Google / Email" (i.e. sign-in with upgrade).
 */
export async function ensureSignedIn(): Promise<User> {
  if (auth.currentUser) return auth.currentUser;
  const cred = await signInAnonymously(auth);
  return cred.user;
}

export function isGuest(): boolean {
  return !!auth.currentUser?.isAnonymous;
}

/**
 * Upgrades the current guest session to a real Google account when
 * possible (same uid, all data carries over automatically), or signs in
 * fresh if the device wasn't a guest for some reason.
 *
 * `idToken` comes from your platform's Google Sign-In SDK, e.g.
 * @react-native-google-signin/google-signin's GoogleSignin.signIn().
 */
export async function signInWithGoogle(idToken: string): Promise<User> {
  const credential = GoogleAuthProvider.credential(idToken);
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithCredential(auth.currentUser, credential);
    return result.user;
  }
  const result = await signInWithCredential(auth, credential);
  return result.user;
}

/**
 * Passwordless email sign-in, step 1: send the link. `continueUrl` must be
 * an allowed domain in the Firebase console (Authentication > Settings >
 * Authorized domains) and should deep-link back into the app.
 * Persist `email` yourself (e.g. AsyncStorage under EMAIL_LINK_STORAGE_KEY)
 * so completeEmailSignIn can read it back when the link is opened.
 */
export async function sendEmailSignInLink(
  email: string,
  continueUrl: string
): Promise<void> {
  await sendSignInLinkToEmail(auth, email, {
    url: continueUrl,
    handleCodeInApp: true,
  });
}

/**
 * Passwordless email sign-in, step 2: call this when the app is opened via
 * the emailed link (e.g. from your deep-link handler). Upgrades a guest
 * session in place, same as signInWithGoogle.
 */
export async function completeEmailSignIn(
  currentUrl: string,
  storedEmail: string
): Promise<User | null> {
  if (!isSignInWithEmailLink(auth, currentUrl)) return null;
  const credential = EmailAuthProvider.credentialWithLink(
    storedEmail,
    currentUrl
  );
  if (auth.currentUser?.isAnonymous) {
    const result = await linkWithCredential(auth.currentUser, credential);
    return result.user;
  }
  const result = await signInWithEmailLink(auth, storedEmail, currentUrl);
  return result.user;
}

/** Signs out fully. Note: this does NOT delete the account — see
 * deleteAccount() below, required separately by Google Play policy. */
export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

/**
 * Google Play's User Data policy requires apps that let users create an
 * account to also let them delete it, in-app, permanently (not just sign
 * out or deactivate). Wire this to a confirmed "Delete my account" button
 * in Settings once Phase 2's Firestore data exists to also clean up.
 */
export async function deleteAccount(): Promise<void> {
  const u = auth.currentUser;
  if (!u) return;
  await u.delete();
  // Phase 2 TODO: also delete/anonymize this user's docs in Firestore
  // (best done via a Cloud Function triggered on auth user deletion,
  // so it happens even if the app is closed mid-way through).
}
