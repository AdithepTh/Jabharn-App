/**
 * Requires: npm install i18next react-i18next expo-localization
 * (swap expo-localization for react-native-localize if not using Expo)
 */
import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import * as Localization from "expo-localization";
import en from "./locales/en.json";
import th from "./locales/th.json";

const deviceLang = Localization.getLocales()[0]?.languageCode ?? "th";

i18n.use(initReactI18next).init({
  resources: {
    en: { translation: en },
    th: { translation: th },
  },
  lng: deviceLang === "en" ? "en" : "th", // default to Thai for anything else
  fallbackLng: "th",
  interpolation: { escapeValue: false },
});

/** Call from a Settings screen toggle. Persist the choice yourself
 * (e.g. AsyncStorage) and re-apply it via this function on app startup,
 * so it overrides the device-locale default above. */
export function setAppLanguage(lang: "en" | "th") {
  i18n.changeLanguage(lang);
}

export default i18n;
