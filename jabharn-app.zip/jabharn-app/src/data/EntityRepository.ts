export interface WithLifecycle {
  id: string;
  deletedAt?: string | null;
  updatedAt: string;
}

/**
 * Every screen in the app talks to data through this interface only.
 * LocalRepository (phase 1, active) and CloudRepository (phase 2, behind
 * FEATURE_FLAGS.SHARE_ENABLED) both implement it identically, so switching
 * backends later is a one-line change in repositoryFactory.ts.
 */
export interface EntityRepository<T extends WithLifecycle> {
  /** Active (non-trashed) records, newest first. */
  list(): Promise<T[]>;

  /** Soft-deleted records still inside the retention window. */
  listTrash(): Promise<T[]>;

  get(id: string): Promise<T | null>;

  /** Create or fully overwrite a record. */
  save(entity: T): Promise<void>;

  /** Move a record to the trash (sets deletedAt). Does not remove data. */
  softDelete(id: string): Promise<void>;

  /** Bring a trashed record back (clears deletedAt). */
  restore(id: string): Promise<void>;

  /** Permanently remove anything trashed longer than retentionDays.
   * Safe to call often (e.g. on app start) — it's a no-op if nothing
   * has expired yet. */
  purgeExpiredTrash(retentionDays: number): Promise<void>;

  /**
   * Live-updates for one record. LocalRepository resolves once (there's
   * nothing to "subscribe" to on a single device); CloudRepository (phase 2)
   * wires this to a Firestore onSnapshot listener for realtime sync.
   * Always returns an unsubscribe function.
   */
  subscribe(id: string, onChange: (entity: T | null) => void): () => void;
}
