export type ID = string;

/** Fields shared by every record a repository can store. */
export interface BaseRecord {
  id: ID;
  name: string;
  members: string[];
  createdAt: string;
  updatedAt: string;
  closed?: boolean;

  /** Soft-delete marker. null/undefined = active. Set by softDelete(),
   * cleared by restore(), and used by purgeExpiredTrash() to decide what's
   * old enough to remove for good. */
  deletedAt?: string | null;

  /** Phase 2 fields — unused while FEATURE_FLAGS.SHARE_ENABLED is false,
   * but included now so LocalRepository and CloudRepository share one
   * schema and no migration is needed later. */
  ownerId?: string;
  memberIds?: string[];
  shareCode?: string | null;
}

export interface SplitEntry {
  amount: number;
  paidBy: string;
  splitAmong: string[];
}

export interface Accommodation extends SplitEntry {
  id: ID;
  night: string; // ISO date
  place: string;
  photo?: string | null; // compressed base64 data URL
}

export type ExpenseCategory = "food" | "beer" | "liquor" | "other";

export interface MealItem extends SplitEntry {
  id: ID;
  desc: string;
  category: ExpenseCategory;
  photo?: string | null;
}

export interface Meal {
  id: ID;
  date: string;
  mealType: "breakfast" | "lunch" | "dinner" | "snack";
  place: string;
  paidBy: string;
  items: MealItem[];
  closed?: boolean;
}

export interface PartyExpense extends SplitEntry {
  id: ID;
  desc: string;
  photo?: string | null;
}

export interface Trip extends BaseRecord {
  kind: "trip";
  province?: string;
  startDate?: string;
  endDate?: string;
  accommodations: Accommodation[];
  meals: Meal[];
}

export interface Party extends BaseRecord {
  kind: "party";
  date?: string;
  expenses: PartyExpense[];
}
