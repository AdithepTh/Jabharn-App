/**
 * PHASE 2 — written now, not active yet.
 *
 * This becomes live the moment FEATURE_FLAGS.SHARE_ENABLED is flipped to
 * true in src/config/featureFlags.ts (see repositoryFactory.ts). Nothing
 * else in the app needs to change: every screen already talks only to the
 * EntityRepository interface.
 *
 * Requires (install only when you start phase 2):
 *   npm install firebase
 * and a configured src/firebase/firebaseConfig.ts, plus the security rules
 * in /firestore.rules deployed to your Firebase project.
 */
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  setDoc,
  onSnapshot,
  type Firestore,
  type CollectionReference,
} from "firebase/firestore";
import { firebaseApp } from "../firebase/firebaseConfig";
import { EntityRepository, WithLifecycle } from "./EntityRepository";

const db: Firestore = getFirestore(firebaseApp);

export class CloudRepository<T extends WithLifecycle>
  implements EntityRepository<T>
{
  private col: CollectionReference;

  constructor(
    namespace: "trips" | "parties",
    private currentUserId: () => string
  ) {
    this.col = collection(db, namespace);
  }

  async list(): Promise<T[]> {
    const q = query(
      this.col,
      where("memberIds", "array-contains", this.currentUserId()),
      orderBy("updatedAt", "desc")
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as T).filter((e) => !e.deletedAt);
  }

  async listTrash(): Promise<T[]> {
    const q = query(
      this.col,
      where("memberIds", "array-contains", this.currentUserId()),
      where("deletedAt", "!=", null)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as T);
  }

  async get(id: string): Promise<T | null> {
    const snap = await getDoc(doc(this.col, id));
    return snap.exists() ? (snap.data() as T) : null;
  }

  async save(entity: T): Promise<void> {
    await setDoc(
      doc(this.col, entity.id),
      { ...entity, updatedAt: new Date().toISOString() },
      { merge: true }
    );
  }

  async softDelete(id: string): Promise<void> {
    await setDoc(
      doc(this.col, id),
      { deletedAt: new Date().toISOString() },
      { merge: true }
    );
  }

  async restore(id: string): Promise<void> {
    await setDoc(doc(this.col, id), { deletedAt: null }, { merge: true });
  }

  /** Intentionally a client no-op. Hard deletion of expired trash happens
   * server-side via the scheduled Cloud Function in /functions/purgeTrash.js,
   * so it still runs even if nobody opens the app that day. */
  async purgeExpiredTrash(): Promise<void> {
    return;
  }

  /** This is the one method LocalRepository can't meaningfully implement —
   * realtime sync is the whole point of phase 2. Every device with this
   * trip open gets pushed the new state the instant anyone else edits it. */
  subscribe(id: string, onChange: (entity: T | null) => void): () => void {
    return onSnapshot(doc(this.col, id), (snap) => {
      onChange(snap.exists() ? (snap.data() as T) : null);
    });
  }
}
