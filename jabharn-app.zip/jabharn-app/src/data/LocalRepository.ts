import AsyncStorage from "@react-native-async-storage/async-storage";
import { EntityRepository, WithLifecycle } from "./EntityRepository";

/**
 * Phase 1 default implementation. Everything lives in AsyncStorage on the
 * user's device — zero backend, zero cost, works fully offline. This is
 * what repositoryFactory.ts hands out while FEATURE_FLAGS.SHARE_ENABLED
 * is false.
 */
export class LocalRepository<T extends WithLifecycle>
  implements EntityRepository<T>
{
  private storageKey: string;

  constructor(namespace: "trips" | "parties") {
    this.storageKey = `jabharn:${namespace}`;
  }

  private async readAll(): Promise<T[]> {
    const raw = await AsyncStorage.getItem(this.storageKey);
    return raw ? (JSON.parse(raw) as T[]) : [];
  }

  private async writeAll(items: T[]): Promise<void> {
    await AsyncStorage.setItem(this.storageKey, JSON.stringify(items));
  }

  async list(): Promise<T[]> {
    const all = await this.readAll();
    return all
      .filter((e) => !e.deletedAt)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  async listTrash(): Promise<T[]> {
    const all = await this.readAll();
    return all
      .filter((e) => !!e.deletedAt)
      .sort((a, b) => (b.deletedAt ?? "").localeCompare(a.deletedAt ?? ""));
  }

  async get(id: string): Promise<T | null> {
    const all = await this.readAll();
    return all.find((e) => e.id === id) ?? null;
  }

  async save(entity: T): Promise<void> {
    const all = await this.readAll();
    const idx = all.findIndex((e) => e.id === entity.id);
    const next: T = { ...entity, updatedAt: new Date().toISOString() };
    if (idx >= 0) all[idx] = next;
    else all.unshift(next);
    await this.writeAll(all);
  }

  async softDelete(id: string): Promise<void> {
    const all = await this.readAll();
    const idx = all.findIndex((e) => e.id === id);
    if (idx < 0) return;
    all[idx] = { ...all[idx], deletedAt: new Date().toISOString() };
    await this.writeAll(all);
  }

  async restore(id: string): Promise<void> {
    const all = await this.readAll();
    const idx = all.findIndex((e) => e.id === id);
    if (idx < 0) return;
    all[idx] = { ...all[idx], deletedAt: null };
    await this.writeAll(all);
  }

  async purgeExpiredTrash(retentionDays: number): Promise<void> {
    const all = await this.readAll();
    const cutoff = Date.now() - retentionDays * 24 * 60 * 60 * 1000;
    const kept = all.filter((e) => {
      if (!e.deletedAt) return true;
      return new Date(e.deletedAt).getTime() > cutoff;
    });
    if (kept.length !== all.length) await this.writeAll(kept);
  }

  /** Nothing external can change local data out from under the app, so this
   * just resolves once with the current value. Kept so screens can call
   * repo.subscribe(...) the same way no matter which repository is active. */
  subscribe(id: string, onChange: (entity: T | null) => void): () => void {
    let cancelled = false;
    this.get(id).then((e) => {
      if (!cancelled) onChange(e);
    });
    return () => {
      cancelled = true;
    };
  }
}
