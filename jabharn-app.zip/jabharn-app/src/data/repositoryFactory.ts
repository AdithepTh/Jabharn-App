import { FEATURE_FLAGS } from "../config/featureFlags";
import { LocalRepository } from "./LocalRepository";
import { CloudRepository } from "./CloudRepository";
import type { EntityRepository } from "./EntityRepository";
import type { Trip, Party } from "./types";
import { getCurrentUserId } from "../auth/AuthService";

/**
 * The ONLY place in the app that knows whether we're offline (phase 1) or
 * synced (phase 2). Every screen calls createTripRepository() /
 * createPartyRepository() and uses the EntityRepository interface —
 * nothing else needs to know or care which implementation it got.
 */
export function createTripRepository(): EntityRepository<Trip> {
  return FEATURE_FLAGS.SHARE_ENABLED
    ? new CloudRepository<Trip>("trips", getCurrentUserId)
    : new LocalRepository<Trip>("trips");
}

export function createPartyRepository(): EntityRepository<Party> {
  return FEATURE_FLAGS.SHARE_ENABLED
    ? new CloudRepository<Party>("parties", getCurrentUserId)
    : new LocalRepository<Party>("parties");
}
