/**
 * Central switchboard for features that exist in code but aren't live yet.
 *
 * Phase 1 ships with SHARE_ENABLED = false: the app is fully offline,
 * zero backend cost, and every screen reads/writes through LocalRepository
 * (see src/data/LocalRepository.ts).
 *
 * Phase 2: once a Firebase project + Firestore security rules are deployed
 * and tested, flip SHARE_ENABLED to true. repositoryFactory.ts will then
 * hand out CloudRepository instances instead — no UI code needs to change,
 * because both repositories implement the same EntityRepository interface.
 */
export const FEATURE_FLAGS = {
  SHARE_ENABLED: false,
};

/** How long a soft-deleted trip/party stays in the trash before it's purged
 * for good. 30 days matches the convention users already know from Google
 * Drive / Gmail / iCloud, so nobody has to think about it. */
export const TRASH_RETENTION_DAYS = 30;
