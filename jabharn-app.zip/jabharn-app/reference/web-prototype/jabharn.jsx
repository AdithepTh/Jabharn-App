import React, { useState, useEffect, useCallback } from "react";
import {
  Plus, ArrowLeft, Trash2, Users, Receipt, Wallet, ArrowRight, X, RotateCcw,
  Check, MapPin, Bed, UtensilsCrossed, BarChart3, Search, Pencil,
  Camera, Lock, Unlock,
} from "lucide-react";

const STORAGE_KEY = "jabharn_v2";

const uid = (p) => `${p}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
const fmt = (n) =>
  round2(n).toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtDate = (d) => {
  if (!d) return "";
  try {
    return new Date(d).toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" });
  } catch {
    return d;
  }
};

function bytesOf(obj) {
  try { return new Blob([JSON.stringify(obj)]).size; } catch { return JSON.stringify(obj).length; }
}
function formatBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}
const STORAGE_LIMIT_BYTES = 5 * 1024 * 1024;
function countPhotos(data) {
  let c = 0;
  data.trips.forEach((t) => {
    t.accommodations.forEach((a) => { if (a.photo) c++; });
    t.meals.forEach((m) => m.items.forEach((it) => { if (it.photo) c++; }));
  });
  data.parties.forEach((p) => { p.expenses.forEach((e) => { if (e.photo) c++; }); });
  return c;
}
function stripPhotosFromTrip(t) {
  return {
    ...t,
    accommodations: t.accommodations.map((a) => (a.photo ? { ...a, photo: null } : a)),
    meals: t.meals.map((m) => ({ ...m, items: m.items.map((it) => (it.photo ? { ...it, photo: null } : it)) })),
  };
}
function stripPhotosFromParty(p) {
  return { ...p, expenses: p.expenses.map((e) => (e.photo ? { ...e, photo: null } : e)) };
}

const MEAL_TYPES = [
  { v: "breakfast", l: "มื้อเช้า" },
  { v: "lunch", l: "มื้อกลางวัน" },
  { v: "dinner", l: "มื้อเย็น" },
  { v: "snack", l: "ของว่าง/มื้อดึก" },
];
const CATS = [
  { v: "food", l: "อาหาร", cls: "cat-food" },
  { v: "beer", l: "เบียร์", cls: "cat-beer" },
  { v: "liquor", l: "เหล้า", cls: "cat-liquor" },
  { v: "other", l: "อื่นๆ", cls: "cat-other" },
];
const catLabel = (v) => (CATS.find((c) => c.v === v) || {}).l || v;
const catCls = (v) => (CATS.find((c) => c.v === v) || {}).cls || "cat-other";

// ---------- image compression (client-side, no upload needed) ----------
function compressImage(file, maxWidth = 900, quality = 0.55) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => reject(new Error("โหลดรูปไม่สำเร็จ"));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error("อ่านไฟล์ไม่สำเร็จ"));
    reader.readAsDataURL(file);
  });
}

// ---------- balance engine (generic) ----------
function computeBalancesFromEntries(members, entries) {
  const paid = {}, owed = {};
  members.forEach((m) => { paid[m] = 0; owed[m] = 0; });
  entries.forEach((e) => {
    if (!e.splitAmong || e.splitAmong.length === 0) return;
    paid[e.paidBy] = (paid[e.paidBy] || 0) + e.amount;
    const share = e.amount / e.splitAmong.length;
    e.splitAmong.forEach((m) => { owed[m] = (owed[m] || 0) + share; });
  });
  const net = {};
  members.forEach((m) => { net[m] = round2((paid[m] || 0) - (owed[m] || 0)); });
  return net;
}
function simplifyDebts(net) {
  const debtors = Object.entries(net).filter(([, v]) => v < -0.01).sort((a, b) => a[1] - b[1]).map(([k, v]) => [k, v]);
  const creditors = Object.entries(net).filter(([, v]) => v > 0.01).sort((a, b) => b[1] - a[1]).map(([k, v]) => [k, v]);
  const tx = [];
  let i = 0, j = 0;
  while (i < debtors.length && j < creditors.length) {
    const d = debtors[i], c = creditors[j];
    const amt = Math.min(-d[1], c[1]);
    if (amt > 0.005) tx.push({ from: d[0], to: c[0], amount: round2(amt) });
    d[1] += amt; c[1] -= amt;
    if (Math.abs(d[1]) < 0.01) i++;
    if (Math.abs(c[1]) < 0.01) j++;
  }
  return tx;
}

// ---------- trip-specific helpers ----------
function tripEntries(trip) {
  const acc = trip.accommodations.map((a) => ({ amount: a.amount, paidBy: a.paidBy, splitAmong: a.splitAmong }));
  const meals = trip.meals.flatMap((m) =>
    m.items.map((it) => ({ amount: it.amount, paidBy: m.paidBy, splitAmong: it.splitAmong }))
  );
  return [...acc, ...meals];
}
function tripTotal(trip) {
  return round2(tripEntries(trip).reduce((s, e) => s + e.amount, 0));
}
function tripCategoryTotals(trip) {
  const t = { accommodation: 0, food: 0, beer: 0, liquor: 0, other: 0 };
  trip.accommodations.forEach((a) => (t.accommodation += a.amount));
  trip.meals.forEach((m) => m.items.forEach((it) => (t[it.category] = (t[it.category] || 0) + it.amount)));
  Object.keys(t).forEach((k) => (t[k] = round2(t[k])));
  return t;
}
function tripPersonBreakdown(trip) {
  const breakdown = {};
  trip.members.forEach((m) => (breakdown[m] = { accommodation: 0, food: 0, beer: 0, liquor: 0, other: 0, paid: 0 }));
  trip.accommodations.forEach((a) => {
    breakdown[a.paidBy] && (breakdown[a.paidBy].paid += a.amount);
    const share = a.amount / a.splitAmong.length;
    a.splitAmong.forEach((m) => breakdown[m] && (breakdown[m].accommodation += share));
  });
  trip.meals.forEach((m) => {
    m.items.forEach((it) => {
      breakdown[m.paidBy] && (breakdown[m.paidBy].paid += it.amount);
      const share = it.amount / it.splitAmong.length;
      it.splitAmong.forEach((mem) => breakdown[mem] && (breakdown[mem][it.category] += share));
    });
  });
  Object.values(breakdown).forEach((b) => Object.keys(b).forEach((k) => (b[k] = round2(b[k]))));
  return breakdown;
}
function partyTotal(p) {
  return round2(p.expenses.reduce((s, e) => s + e.amount, 0));
}

function matchesSearch(item, q) {
  if (!q) return true;
  const s = q.toLowerCase();
  if (item.kind === "trip") {
    if ((item.name || "").toLowerCase().includes(s)) return true;
    if ((item.province || "").toLowerCase().includes(s)) return true;
    if (item.accommodations.some((a) => (a.place || "").toLowerCase().includes(s))) return true;
    if (item.meals.some((m) => (m.place || "").toLowerCase().includes(s))) return true;
    return false;
  }
  return (item.name || "").toLowerCase().includes(s);
}

function TornCard({ children, className = "", onClick }) {
  return (
    <div className={`ps-card ${className}`} onClick={onClick}>
      <div className="ps-card-body">{children}</div>
      <div className="ps-torn" />
    </div>
  );
}

function ClosedBanner({ onReopen, label = "ปิดรายการนี้แล้ว" }) {
  return (
    <div className="ps-closed-banner">
      <span><Lock size={13} /> {label} — แก้ไขเพิ่มเติมไม่ได้จนกว่าจะเปิดอีกครั้ง</span>
      <button className="ps-btn-ghost" onClick={onReopen}><Unlock size={13} /> เปิดแก้ไขอีกครั้ง</button>
    </div>
  );
}

// ================= APP ROOT =================
export default function App() {
  const [data, setData] = useState({ trips: [], parties: [] });
  const [loaded, setLoaded] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const [view, setView] = useState("home");
  const [selectedId, setSelectedId] = useState(null);
  const [query, setQuery] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get(STORAGE_KEY, false);
        if (res && res.value) setData(JSON.parse(res.value));
      } catch (e) {}
      setLoaded(true);
    })();
  }, []);

  const persist = useCallback(async (next) => {
    setData(next);
    try {
      const res = await window.storage.set(STORAGE_KEY, JSON.stringify(next), false);
      setSaveError(!res);
    } catch (e) {
      setSaveError(true);
    }
  }, []);

  const createTrip = (name, province, startDate, endDate, members) => {
    const trip = {
      id: uid("trip"), kind: "trip", name, province, startDate, endDate,
      createdAt: new Date().toISOString(), members, accommodations: [], meals: [], closed: false,
    };
    persist({ ...data, trips: [trip, ...data.trips] });
    setSelectedId(trip.id); setView("trip");
  };
  const updateTrip = (id, fn) => persist({ ...data, trips: data.trips.map((t) => (t.id === id ? fn(t) : t)) });
  const deleteTrip = (id) => { persist({ ...data, trips: data.trips.filter((t) => t.id !== id) }); setView("home"); };

  const createParty = (kindLabel, name, date, members) => {
    const party = {
      id: uid("pty"), kind: kindLabel, name, date, members,
      createdAt: new Date().toISOString(), expenses: [], closed: false,
    };
    persist({ ...data, parties: [party, ...data.parties] });
    setSelectedId(party.id); setView("party");
    return party;
  };
  const updateParty = (id, fn) => persist({ ...data, parties: data.parties.map((p) => (p.id === id ? fn(p) : p)) });
  const deleteParty = (id) => { persist({ ...data, parties: data.parties.filter((p) => p.id !== id) }); setView("home"); };

  const resetAll = () => {
    if (window.confirm("ล้างข้อมูลทั้งหมด (ทริป/ปาร์ตี้/ประวัติ)? ทำแล้วกู้คืนไม่ได้นะ")) {
      persist({ trips: [], parties: [] });
      setView("home");
    }
  };

  const clearAllPhotos = () => {
    if (window.confirm("ลบรูปใบเสร็จทั้งหมดในทุกทริป/ปาร์ตี้? รายการและยอดเงินยังอยู่ครบ ลบแค่รูปภาพเพื่อประหยัดพื้นที่")) {
      persist({ trips: data.trips.map(stripPhotosFromTrip), parties: data.parties.map(stripPhotosFromParty) });
    }
  };

  const clearTripPhotos = (tripId) => {
    if (window.confirm("ลบรูปใบเสร็จทั้งหมดในทริปนี้? รายการและยอดเงินยังอยู่ครบ ลบแค่รูปภาพ")) {
      updateTrip(tripId, stripPhotosFromTrip);
    }
  };

  const clearPartyPhotos = (partyId) => {
    if (window.confirm("ลบรูปใบเสร็จทั้งหมดในปาร์ตี้นี้? รายการและยอดเงินยังอยู่ครบ ลบแค่รูปภาพ")) {
      updateParty(partyId, stripPhotosFromParty);
    }
  };

  const reloadData = async () => {
    try {
      const res = await window.storage.get(STORAGE_KEY, false);
      if (res && res.value) setData(JSON.parse(res.value));
    } catch (e) {}
  };

  const selectedTrip = data.trips.find((t) => t.id === selectedId);
  const selectedParty = data.parties.find((p) => p.id === selectedId);
  const hasAny = data.trips.length > 0 || data.parties.length > 0;

  return (
    <div className="ps-app">
      <GlobalStyle />
      <div className="ps-shell">
        <div className="ps-header">
          <div>
            <h1 className="ps-title">Jabharn <span className="ps-title-th">จับหาร</span></h1>
            <p className="ps-subtitle">จดทริป แชร์บิล จบทุกเรื่องเงินในกลุ่มเพื่อน</p>
          </div>
          {hasAny && (
            <div style={{ display: "flex", gap: 6 }}>
              <button className="ps-reset-btn" onClick={reloadData} title="รีเฟรชข้อมูล">
                <RotateCcw size={13} /> รีเฟรช
              </button>
              <button className="ps-reset-btn" onClick={resetAll} title="ล้างข้อมูลทั้งหมด">
                <Trash2 size={13} /> ล้างข้อมูล
              </button>
            </div>
          )}
        </div>

        {!loaded && <div className="ps-empty">กำลังโหลดข้อมูล...</div>}

        {loaded && view === "home" && (
          <Home
            data={data} query={query} setQuery={setQuery}
            onNewTrip={() => setView("newTrip")}
            onNewParty={() => setView("newParty")}
            onOpenTrip={(id) => { setSelectedId(id); setView("trip"); }}
            onOpenParty={(id) => { setSelectedId(id); setView("party"); }}
            onClearAllPhotos={clearAllPhotos}
          />
        )}

        {loaded && view === "newTrip" && <NewTripForm onCancel={() => setView("home")} onCreate={createTrip} />}

        {loaded && view === "trip" && selectedTrip && (
          <TripDetail
            trip={selectedTrip}
            onBack={() => setView("home")}
            onUpdate={(fn) => updateTrip(selectedTrip.id, fn)}
            onDelete={() => deleteTrip(selectedTrip.id)}
            onClearPhotos={() => clearTripPhotos(selectedTrip.id)}
          />
        )}

        {loaded && view === "newParty" && (
          <NewPartyForm
            title="สร้างปาร์ตี้"
            hint="เช่น ปาร์ตี้วันเกิดตูน, มื้อเย็นเพื่อน, หรือหารบิลด่วน"
            onCancel={() => setView("home")}
            onCreate={(name, date, members) => createParty("party", name, date, members)}
          />
        )}

        {loaded && view === "party" && selectedParty && (
          <PartyDetail
            party={selectedParty}
            onBack={() => setView("home")}
            onUpdate={(fn) => updateParty(selectedParty.id, fn)}
            onDelete={() => deleteParty(selectedParty.id)}
            onClearPhotos={() => clearPartyPhotos(selectedParty.id)}
          />
        )}

        {saveError && <p style={{ fontSize: 12, color: "var(--brick)", marginTop: 16 }}>บันทึกข้อมูลไม่สำเร็จ ลองอีกครั้ง</p>}
      </div>
    </div>
  );
}

// ================= HOME =================
function Home({ data, query, setQuery, onNewTrip, onNewParty, onOpenTrip, onOpenParty, onClearAllPhotos }) {
  const combined = [...data.trips.map((t) => ({ ...t, kind: "trip" })), ...data.parties]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const filtered = combined.filter((item) => matchesSearch(item, query));

  const usedBytes = bytesOf(data);
  const pct = Math.min(100, (usedBytes / STORAGE_LIMIT_BYTES) * 100);
  const photoCount = countPhotos(data);
  const usageLevel = pct > 80 ? "danger" : pct > 50 ? "warn" : "ok";

  return (
    <div>
      <div className="ps-create-grid">
        <button className="ps-create-card" onClick={onNewTrip}>
          <MapPin size={20} /><span>สร้างทริป</span><small>วันไป-กลับ ที่พัก อาหารแยกรายมื้อ</small>
        </button>
        <button className="ps-create-card" onClick={onNewParty}>
          <Users size={20} /><span>สร้างปาร์ตี้ / แชร์บิล</span><small>ใส่วันที่หรือไม่ก็ได้ เหมาะกับมื้อเดียว งานเดียว หรือคำนวณด่วน</small>
        </button>
      </div>

      {combined.length > 0 && (
        <div className="ps-storage-box">
          <div className="ps-storage-row">
            <span>พื้นที่ใช้งาน: {formatBytes(usedBytes)} / ~5MB {photoCount > 0 ? `· รูปแนบ ${photoCount} รูป` : ""}</span>
            {photoCount > 0 && (
              <button className="ps-storage-clear" onClick={onClearAllPhotos}><Trash2 size={11} /> ลบรูปทั้งหมด</button>
            )}
          </div>
          <div className="ps-storage-bar"><div className={`ps-storage-fill ${usageLevel}`} style={{ width: `${pct}%` }} /></div>
        </div>
      )}

      {combined.length > 0 && (
        <div className="ps-search-wrap">
          <Search size={15} className="ps-search-icon" />
          <input className="ps-input ps-search-input" placeholder="ค้นหาทริป จังหวัด ร้าน หรือโรงแรม..." value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
      )}

      {combined.length === 0 && <div className="ps-empty">ยังไม่มีทริปหรือปาร์ตี้ — เริ่มจากปุ่มด้านบนได้เลย</div>}
      {combined.length > 0 && filtered.length === 0 && <div className="ps-empty">ไม่พบผลลัพธ์ที่ตรงกับ "{query}"</div>}

      <div className="ps-grid">
        {filtered.map((item) =>
          item.kind === "trip" ? (
            <TripCard key={item.id} trip={item} onClick={() => onOpenTrip(item.id)} />
          ) : (
            <PartyCard key={item.id} party={item} onClick={() => onOpenParty(item.id)} />
          )
        )}
      </div>
    </div>
  );
}

function StatusBadge({ closed, pending }) {
  if (closed) return <span className="ps-badge closed">ปิดแล้ว ✓</span>;
  return <span className={`ps-badge ${pending === 0 ? "settled" : "pending"}`}>{pending === 0 ? "ลงตัวแล้ว" : `ค้าง ${pending} รายการ`}</span>;
}

function TripCard({ trip, onClick }) {
  const total = tripTotal(trip);
  const net = computeBalancesFromEntries(trip.members, tripEntries(trip));
  const pending = simplifyDebts(net).length;
  return (
    <TornCard className="ps-trip-card" onClick={onClick}>
      <span className="ps-kind-badge kind-trip">ทริป</span>
      <p className="ps-trip-name">{trip.name}</p>
      <p className="ps-trip-meta">{trip.province ? `${trip.province} · ` : ""}{fmtDate(trip.startDate)}{trip.endDate ? ` - ${fmtDate(trip.endDate)}` : ""}</p>
      <p className="ps-trip-meta"><Users size={11} style={{ display: "inline", marginRight: 4, verticalAlign: -1 }} />{trip.members.length} คน</p>
      <div className="ps-trip-total-row">
        <span className="ps-mono ps-trip-total">฿{fmt(total)}</span>
        <StatusBadge closed={trip.closed} pending={pending} />
      </div>
    </TornCard>
  );
}

function PartyCard({ party, onClick }) {
  const total = partyTotal(party);
  const net = computeBalancesFromEntries(party.members, party.expenses);
  const pending = simplifyDebts(net).length;
  const label = party.kind === "quick" ? "แชร์ด่วน" : "ปาร์ตี้";
  return (
    <TornCard className="ps-trip-card" onClick={onClick}>
      <span className={`ps-kind-badge ${party.kind === "quick" ? "kind-quick" : "kind-party"}`}>{label}</span>
      <p className="ps-trip-name">{party.name}</p>
      <p className="ps-trip-meta">{party.date ? fmtDate(party.date) : ""}</p>
      <p className="ps-trip-meta"><Users size={11} style={{ display: "inline", marginRight: 4, verticalAlign: -1 }} />{party.members.length} คน · {party.expenses.length} รายการ</p>
      <div className="ps-trip-total-row">
        <span className="ps-mono ps-trip-total">฿{fmt(total)}</span>
        <StatusBadge closed={party.closed} pending={pending} />
      </div>
    </TornCard>
  );
}

// ================= SHARED INPUTS =================
function MemberChipInput({ members, setMembers }) {
  const [input, setInput] = useState("");
  const add = () => {
    const v = input.trim();
    if (v && !members.includes(v)) { setMembers([...members, v]); setInput(""); }
  };
  return (
    <>
      <div style={{ display: "flex", gap: 8 }}>
        <input className="ps-input" placeholder="พิมพ์ชื่อเล่นแล้วกด Enter" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), add())} />
        <button className="ps-btn-ghost" type="button" onClick={add}><Plus size={14} /> เพิ่ม</button>
      </div>
      {members.length > 0 && (
        <div className="ps-chip-row">
          {members.map((m) => (
            <span className="ps-chip" key={m}>{m}<button onClick={() => setMembers(members.filter((x) => x !== m))}><X size={12} /></button></span>
          ))}
        </div>
      )}
    </>
  );
}

function MemberCheckRow({ members, selected, toggle }) {
  return (
    <div className="ps-check-row">
      {members.map((m) => (
        <button key={m} type="button" className={`ps-check ${selected.includes(m) ? "on" : ""}`} onClick={() => toggle(m)}>
          {selected.includes(m) && <Check size={12} />}{m}
        </button>
      ))}
    </div>
  );
}

function SplitPicker({ members, selected, toggle }) {
  return (
    <>
      <label className="ps-label">หารกับใคร</label>
      <p className="ps-hint">เลือกเฉพาะคนที่ต้องช่วยจ่ายรายการนี้ — ไม่จำเป็นต้องเป็นทุกคนที่กินหรือดื่ม เช่น มื้อครอบครัวที่บางคนเลี้ยง ก็เลือกหารแค่บางคนได้</p>
      <MemberCheckRow members={members} selected={selected} toggle={toggle} />
    </>
  );
}

function PhotoField({ photo, onChange }) {
  const [busy, setBusy] = useState(false);
  const [enlarged, setEnlarged] = useState(false);
  const handleFile = async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setBusy(true);
    try {
      const dataUrl = await compressImage(file);
      onChange(dataUrl);
    } catch (err) {
      window.alert("แนบรูปไม่สำเร็จ ลองใหม่อีกครั้ง");
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  };
  return (
    <div style={{ marginTop: 10 }}>
      <label className="ps-label">แนบรูปใบเสร็จ (ไม่บังคับ)</label>
      {!photo ? (
        <label className="ps-photo-add">
          <Camera size={14} /> {busy ? "กำลังบีบอัดรูป..." : "แนบรูป"}
          <input type="file" accept="image/*" capture="environment" style={{ display: "none" }} onChange={handleFile} disabled={busy} />
        </label>
      ) : (
        <div className="ps-photo-row">
          <img src={photo} className="ps-photo-thumb" onClick={() => setEnlarged(true)} alt="ใบเสร็จ" />
          <button type="button" className="ps-btn-ghost ps-btn-danger" onClick={() => onChange(null)}><Trash2 size={12} /> ลบรูป</button>
        </div>
      )}
      {enlarged && (
        <div className="ps-photo-overlay" onClick={() => setEnlarged(false)}>
          <img src={photo} alt="ใบเสร็จ" />
        </div>
      )}
    </div>
  );
}

function PhotoThumbSmall({ photo }) {
  const [enlarged, setEnlarged] = useState(false);
  if (!photo) return null;
  return (
    <>
      <img src={photo} className="ps-photo-thumb-sm" onClick={(e) => { e.stopPropagation(); setEnlarged(true); }} alt="ใบเสร็จ" />
      {enlarged && (
        <div className="ps-photo-overlay" onClick={() => setEnlarged(false)}><img src={photo} alt="ใบเสร็จ" /></div>
      )}
    </>
  );
}

// ================= NEW TRIP FORM =================
function NewTripForm({ onCancel, onCreate }) {
  const [name, setName] = useState("");
  const [province, setProvince] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [members, setMembers] = useState([]);
  const canCreate = name.trim() && members.length >= 2;

  return (
    <div>
      <div className="ps-backrow">
        <button className="ps-iconbtn" onClick={onCancel}><ArrowLeft size={20} /></button>
        <span style={{ fontWeight: 700 }}>สร้างทริปใหม่</span>
      </div>
      <TornCard>
        <label className="ps-label">ชื่อทริป</label>
        <input className="ps-input" placeholder="เช่น ทริปเชียงใหม่ 3 วัน 2 คืน" value={name} onChange={(e) => setName(e.target.value)} />
        <label className="ps-label">จังหวัด</label>
        <input className="ps-input" placeholder="เช่น เชียงใหม่" value={province} onChange={(e) => setProvince(e.target.value)} />
        <div style={{ display: "flex", gap: 12 }}>
          <div style={{ flex: 1 }}><label className="ps-label">วันไป</label><input className="ps-input" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} /></div>
          <div style={{ flex: 1 }}><label className="ps-label">วันกลับ</label><input className="ps-input" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} /></div>
        </div>
        <label className="ps-label">สมาชิก (ชื่อเล่น อย่างน้อย 2 คน)</label>
        <MemberChipInput members={members} setMembers={setMembers} />
        <div className="ps-form-actions">
          <button className="ps-btn" disabled={!canCreate} onClick={() => onCreate(name.trim(), province.trim(), startDate, endDate, members)}><Check size={15} /> สร้างทริป</button>
          <button className="ps-btn-ghost" onClick={onCancel}>ยกเลิก</button>
        </div>
      </TornCard>
    </div>
  );
}

// ================= TRIP DETAIL =================
function TripDetail({ trip, onBack, onUpdate, onDelete, onClearPhotos }) {
  const [tab, setTab] = useState("accom");
  const readOnly = !!trip.closed;
  const tripPhotoCount =
    trip.accommodations.filter((a) => a.photo).length +
    trip.meals.reduce((s, m) => s + m.items.filter((it) => it.photo).length, 0);

  const addAccommodation = (a) => onUpdate((t) => ({ ...t, accommodations: [...t.accommodations, { id: uid("acc"), ...a }] }));
  const editAccommodation = (id, patch) => onUpdate((t) => ({ ...t, accommodations: t.accommodations.map((a) => (a.id === id ? { ...a, ...patch } : a)) }));
  const deleteAccommodation = (id) => onUpdate((t) => ({ ...t, accommodations: t.accommodations.filter((a) => a.id !== id) }));

  const addMeal = (meal) => onUpdate((t) => ({ ...t, meals: [meal, ...t.meals] }));
  const editMeal = (mealId, patch) => onUpdate((t) => ({ ...t, meals: t.meals.map((m) => (m.id === mealId ? { ...m, ...patch } : m)) }));
  const deleteMeal = (mealId) => onUpdate((t) => ({ ...t, meals: t.meals.filter((m) => m.id !== mealId) }));
  const addMealItem = (mealId, item) => onUpdate((t) => ({ ...t, meals: t.meals.map((m) => (m.id === mealId ? { ...m, items: [...m.items, item] } : m)) }));
  const editMealItem = (mealId, itemId, patch) => onUpdate((t) => ({ ...t, meals: t.meals.map((m) => (m.id === mealId ? { ...m, items: m.items.map((it) => (it.id === itemId ? { ...it, ...patch } : it)) } : m)) }));
  const deleteMealItem = (mealId, itemId) => onUpdate((t) => ({ ...t, meals: t.meals.map((m) => (m.id === mealId ? { ...m, items: m.items.filter((it) => it.id !== itemId) } : m)) }));

  return (
    <div>
      <div className="ps-backrow">
        <button className="ps-iconbtn" onClick={onBack}><ArrowLeft size={20} /></button>
        <span style={{ fontWeight: 700, flex: 1 }}>{trip.name}</span>
        <button className="ps-btn-ghost" onClick={() => onUpdate((t) => ({ ...t, closed: !t.closed, closedAt: !t.closed ? new Date().toISOString() : null }))}>
          {trip.closed ? <><Unlock size={13} /> เปิดแก้ไข</> : <><Lock size={13} /> จบทริป</>}
        </button>
        {tripPhotoCount > 0 && (
          <button className="ps-btn-ghost" onClick={onClearPhotos} title="ลบรูปใบเสร็จทั้งหมดในทริปนี้ (เก็บรายการไว้)">
            <Camera size={13} /> ลบรูป ({tripPhotoCount})
          </button>
        )}
        <button className="ps-btn-ghost ps-btn-danger" onClick={onDelete}><Trash2 size={13} /> ลบทริป</button>
      </div>
      <div className="ps-members-strip"><MapPin size={13} /> {trip.province || "ไม่ระบุจังหวัด"} · {fmtDate(trip.startDate)}{trip.endDate ? ` - ${fmtDate(trip.endDate)}` : ""}</div>
      <div className="ps-members-strip"><Users size={13} /> {trip.members.join(" · ")}</div>

      {readOnly && <ClosedBanner label="ปิดทริปนี้แล้ว" onReopen={() => onUpdate((t) => ({ ...t, closed: false, closedAt: null }))} />}

      <div className="ps-tabs">
        <button className={`ps-tab ${tab === "accom" ? "on" : ""}`} onClick={() => setTab("accom")}><Bed size={14} /> ที่พัก</button>
        <button className={`ps-tab ${tab === "meals" ? "on" : ""}`} onClick={() => setTab("meals")}><UtensilsCrossed size={14} /> อาหาร</button>
        <button className={`ps-tab ${tab === "report" ? "on" : ""}`} onClick={() => setTab("report")}><BarChart3 size={14} /> รายงาน</button>
      </div>

      {tab === "accom" && <AccommodationTab trip={trip} readOnly={readOnly} onAdd={addAccommodation} onEdit={editAccommodation} onDelete={deleteAccommodation} />}
      {tab === "meals" && <MealsTab trip={trip} readOnly={readOnly} onAddMeal={addMeal} onEditMeal={editMeal} onDeleteMeal={deleteMeal} onAddItem={addMealItem} onEditItem={editMealItem} onDeleteItem={deleteMealItem} />}
      {tab === "report" && <ReportTab trip={trip} />}
    </div>
  );
}

function AccommodationTab({ trip, readOnly, onAdd, onEdit, onDelete }) {
  const emptyForm = () => ({ night: trip.startDate || "", place: "", amount: "", paidBy: trip.members[0], splitAmong: trip.members, photo: null });
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm());

  const toggle = (m) => setForm((f) => ({ ...f, splitAmong: f.splitAmong.includes(m) ? f.splitAmong.filter((x) => x !== m) : [...f.splitAmong, m] }));
  const canSubmit = form.place.trim() && Number(form.amount) > 0 && form.splitAmong.length > 0;
  const total = round2(trip.accommodations.reduce((s, a) => s + a.amount, 0));

  const startEdit = (a) => { setEditingId(a.id); setForm({ night: a.night || "", place: a.place, amount: String(a.amount), paidBy: a.paidBy, splitAmong: a.splitAmong, photo: a.photo || null }); };
  const cancelEdit = () => { setEditingId(null); setForm(emptyForm()); };
  const submit = () => {
    const payload = { night: form.night, place: form.place.trim(), amount: round2(Number(form.amount)), paidBy: form.paidBy, splitAmong: form.splitAmong, photo: form.photo };
    if (editingId) onEdit(editingId, payload); else onAdd(payload);
    cancelEdit();
  };

  return (
    <div>
      {!readOnly && (
        <TornCard>
          <p className="ps-section-title"><Plus size={14} /> {editingId ? "แก้ไขค่าที่พัก" : "เพิ่มค่าที่พัก"}</p>
          <label className="ps-label">คืนวันที่</label>
          <input className="ps-input" type="date" value={form.night} onChange={(e) => setForm((f) => ({ ...f, night: e.target.value }))} />
          <label className="ps-label">ชื่อที่พัก/โรงแรม</label>
          <input className="ps-input" placeholder="เช่น บ้านสวนรีสอร์ท" value={form.place} onChange={(e) => setForm((f) => ({ ...f, place: e.target.value }))} />
          <label className="ps-label">จำนวนเงิน (฿)</label>
          <input className="ps-input" type="number" min="0" placeholder="0.00" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
          <label className="ps-label">ใครจ่าย</label>
          <p className="ps-hint">แต่ละคืนเลือกคนจ่ายแยกกันได้ เช่น คืนนี้ A จ่าย คืนหน้า B จ่ายก็ได้</p>
          <select className="ps-select" value={form.paidBy} onChange={(e) => setForm((f) => ({ ...f, paidBy: e.target.value }))}>
            {trip.members.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
          <SplitPicker members={trip.members} selected={form.splitAmong} toggle={toggle} />
          <PhotoField photo={form.photo} onChange={(p) => setForm((f) => ({ ...f, photo: p }))} />
          <div className="ps-form-actions">
            <button className="ps-btn" disabled={!canSubmit} onClick={submit}><Plus size={15} /> {editingId ? "บันทึกการแก้ไข" : "เพิ่มที่พัก"}</button>
            {editingId && <button className="ps-btn-ghost" onClick={cancelEdit}>ยกเลิก</button>}
          </div>
        </TornCard>
      )}

      <TornCard>
        <p className="ps-section-title"><Bed size={14} /> รายการที่พัก ({trip.accommodations.length})</p>
        {trip.accommodations.length === 0 ? (
          <p style={{ color: "var(--ink-soft)", fontSize: 13 }}>ยังไม่มีรายการที่พัก</p>
        ) : (
          <ul className="ps-ledger">
            {trip.accommodations.slice().sort((a, b) => (a.night || "").localeCompare(b.night || "")).map((a) => (
              <li key={a.id}>
                <PhotoThumbSmall photo={a.photo} />
                <div style={{ flex: 1 }}>
                  <div className="ps-ledger-desc">{a.place}</div>
                  <div className="ps-ledger-meta">{fmtDate(a.night)} · {a.paidBy} จ่าย · หาร {a.splitAmong.length} คน</div>
                </div>
                <span className="ps-mono ps-ledger-amt">฿{fmt(a.amount)}</span>
                {!readOnly && (
                  <>
                    <button className="ps-ledger-del" onClick={() => startEdit(a)}><Pencil size={15} /></button>
                    <button className="ps-ledger-del" onClick={() => onDelete(a.id)}><Trash2 size={15} /></button>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
        <div className="ps-total-row"><span className="ps-total-label">รวมค่าที่พัก</span><span className="ps-mono ps-total-amt">฿{fmt(total)}</span></div>
      </TornCard>
    </div>
  );
}

function MealsTab({ trip, readOnly, onAddMeal, onEditMeal, onDeleteMeal, onAddItem, onEditItem, onDeleteItem }) {
  const [date, setDate] = useState(trip.startDate || "");
  const [mealType, setMealType] = useState("dinner");
  const [place, setPlace] = useState("");
  const [paidBy, setPaidBy] = useState(trip.members[0]);
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("food");
  const [splitAmong, setSplitAmong] = useState(trip.members);
  const [photo, setPhoto] = useState(null);

  const toggle = (m) => setSplitAmong((p) => (p.includes(m) ? p.filter((x) => x !== m) : [...p, m]));
  const canSubmit = place.trim() && desc.trim() && Number(amount) > 0 && splitAmong.length > 0;

  const submit = () => {
    onAddMeal({
      id: uid("meal"), date, mealType, place: place.trim(), paidBy, closed: false,
      items: [{ id: uid("item"), desc: desc.trim(), amount: round2(Number(amount)), category, splitAmong, photo }],
    });
    setDesc(""); setAmount(""); setSplitAmong(trip.members); setPhoto(null);
  };

  return (
    <div>
      {!readOnly && (
        <TornCard>
          <p className="ps-section-title"><Plus size={14} /> เพิ่มมื้ออาหารใหม่</p>
          <div style={{ display: "flex", gap: 12 }}>
            <div style={{ flex: 1 }}><label className="ps-label">วันที่</label><input className="ps-input" type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
            <div style={{ flex: 1 }}>
              <label className="ps-label">มื้อ</label>
              <select className="ps-select" value={mealType} onChange={(e) => setMealType(e.target.value)}>
                {MEAL_TYPES.map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}
              </select>
            </div>
          </div>
          <label className="ps-label">ชื่อร้าน</label>
          <input className="ps-input" placeholder="เช่น ร้านลาบเป็ดป้าแดง" value={place} onChange={(e) => setPlace(e.target.value)} />
          <label className="ps-label">ใครจ่าย (บิลนี้)</label>
          <p className="ps-hint">แต่ละมื้อ/แต่ละบิลเลือกคนจ่ายแยกกันได้ เช่น มื้อนี้คุณจ่ายร้านอาหาร แต่บิลเซเว่นให้อีกคนจ่าย ก็สร้างเป็นอีกมื้อแล้วเลือกคนจ่ายต่างกันได้เลย</p>
          <select className="ps-select" value={paidBy} onChange={(e) => setPaidBy(e.target.value)}>
            {trip.members.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>

          <p className="ps-section-title" style={{ marginTop: 18 }}>รายการแรกของมื้อนี้</p>
          <label className="ps-label">รายการ</label>
          <input className="ps-input" placeholder="เช่น ลาบเป็ด, เบียร์ช้าง 3 ขวด" value={desc} onChange={(e) => setDesc(e.target.value)} />
          <label className="ps-label">จำนวนเงิน (฿)</label>
          <input className="ps-input" type="number" min="0" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} />
          <label className="ps-label">ประเภท</label>
          <div className="ps-check-row">
            {CATS.map((c) => (
              <button key={c.v} type="button" className={`ps-check ${category === c.v ? "on" : ""}`} onClick={() => setCategory(c.v)}>{category === c.v && <Check size={12} />} {c.l}</button>
            ))}
          </div>
          <SplitPicker members={trip.members} selected={splitAmong} toggle={toggle} />
          <PhotoField photo={photo} onChange={setPhoto} />
          <div className="ps-form-actions">
            <button className="ps-btn" disabled={!canSubmit} onClick={submit}><Plus size={15} /> เพิ่มมื้ออาหาร</button>
          </div>
        </TornCard>
      )}

      <p className="ps-section-title"><UtensilsCrossed size={14} /> มื้ออาหารทั้งหมด ({trip.meals.length})</p>
      {trip.meals.length === 0 && <p style={{ color: "var(--ink-soft)", fontSize: 13 }}>ยังไม่มีมื้ออาหาร</p>}
      {trip.meals.map((meal) => (
        <MealCard key={meal.id} trip={trip} meal={meal} tripReadOnly={readOnly} onEditMeal={onEditMeal} onAddItem={onAddItem} onEditItem={onEditItem} onDeleteMeal={onDeleteMeal} onDeleteItem={onDeleteItem} />
      ))}
    </div>
  );
}

function MealCard({ trip, meal, tripReadOnly, onEditMeal, onAddItem, onEditItem, onDeleteMeal, onDeleteItem }) {
  const readOnly = tripReadOnly || !!meal.closed;
  const [mode, setMode] = useState(null); // null | 'addItem' | 'editItem' | 'editMeal'
  const [editingItemId, setEditingItemId] = useState(null);
  const emptyItem = () => ({ desc: "", amount: "", category: "food", splitAmong: trip.members, photo: null });
  const [itemForm, setItemForm] = useState(emptyItem());
  const [mealForm, setMealForm] = useState({ date: meal.date, mealType: meal.mealType, place: meal.place, paidBy: meal.paidBy });

  const mealLabel = (MEAL_TYPES.find((m) => m.v === meal.mealType) || {}).l || meal.mealType;
  const mealTotal = round2(meal.items.reduce((s, it) => s + it.amount, 0));
  const toggle = (m) => setItemForm((f) => ({ ...f, splitAmong: f.splitAmong.includes(m) ? f.splitAmong.filter((x) => x !== m) : [...f.splitAmong, m] }));

  const startAddItem = () => { setItemForm(emptyItem()); setEditingItemId(null); setMode("addItem"); };
  const startEditItem = (it) => { setItemForm({ desc: it.desc, amount: String(it.amount), category: it.category, splitAmong: it.splitAmong, photo: it.photo || null }); setEditingItemId(it.id); setMode("editItem"); };
  const cancelItemForm = () => { setMode(null); setEditingItemId(null); };
  const submitItem = () => {
    const payload = { desc: itemForm.desc.trim(), amount: round2(Number(itemForm.amount)), category: itemForm.category, splitAmong: itemForm.splitAmong, photo: itemForm.photo };
    if (editingItemId) onEditItem(meal.id, editingItemId, payload);
    else onAddItem(meal.id, { id: uid("item"), ...payload });
    cancelItemForm();
  };
  const canSubmitItem = itemForm.desc.trim() && Number(itemForm.amount) > 0 && itemForm.splitAmong.length > 0;

  const submitMealEdit = () => { onEditMeal(meal.id, mealForm); setMode(null); };

  return (
    <TornCard>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ flex: 1 }}>
          {mode === "editMeal" ? (
            <div>
              <label className="ps-label">ชื่อร้าน</label>
              <input className="ps-input" value={mealForm.place} onChange={(e) => setMealForm((f) => ({ ...f, place: e.target.value }))} />
              <div style={{ display: "flex", gap: 12 }}>
                <div style={{ flex: 1 }}><label className="ps-label">วันที่</label><input className="ps-input" type="date" value={mealForm.date} onChange={(e) => setMealForm((f) => ({ ...f, date: e.target.value }))} /></div>
                <div style={{ flex: 1 }}>
                  <label className="ps-label">มื้อ</label>
                  <select className="ps-select" value={mealForm.mealType} onChange={(e) => setMealForm((f) => ({ ...f, mealType: e.target.value }))}>
                    {MEAL_TYPES.map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}
                  </select>
                </div>
              </div>
              <label className="ps-label">ใครจ่าย</label>
              <select className="ps-select" value={mealForm.paidBy} onChange={(e) => setMealForm((f) => ({ ...f, paidBy: e.target.value }))}>
                {trip.members.map((m) => <option key={m} value={m}>{m}</option>)}
              </select>
              <div className="ps-form-actions">
                <button className="ps-btn" onClick={submitMealEdit}><Check size={14} /> บันทึก</button>
                <button className="ps-btn-ghost" onClick={() => setMode(null)}>ยกเลิก</button>
              </div>
            </div>
          ) : (
            <>
              <p className="ps-trip-name" style={{ fontSize: 15 }}>{meal.place}</p>
              <p className="ps-ledger-meta">{fmtDate(meal.date)} · {mealLabel} · {meal.paidBy} จ่าย{meal.closed ? " · ปิดมื้อนี้แล้ว" : ""}</p>
            </>
          )}
        </div>
        {!readOnly && mode !== "editMeal" && (
          <div style={{ display: "flex", gap: 4 }}>
            <button className="ps-ledger-del" onClick={() => { setMode("editMeal"); setMealForm({ date: meal.date, mealType: meal.mealType, place: meal.place, paidBy: meal.paidBy }); }}><Pencil size={15} /></button>
            <button className="ps-ledger-del" onClick={() => onDeleteMeal(meal.id)}><Trash2 size={15} /></button>
          </div>
        )}
      </div>

      <ul className="ps-ledger">
        {meal.items.map((it) => (
          <li key={it.id}>
            <PhotoThumbSmall photo={it.photo} />
            <div style={{ flex: 1 }}>
              <div className="ps-ledger-desc">{it.desc} <span className={`ps-cat-tag ${catCls(it.category)}`}>{catLabel(it.category)}</span></div>
              <div className="ps-ledger-meta">หารกับ: {it.splitAmong.join(", ")}</div>
            </div>
            <span className="ps-mono ps-ledger-amt">฿{fmt(it.amount)}</span>
            {!readOnly && (
              <>
                <button className="ps-ledger-del" onClick={() => startEditItem(it)}><Pencil size={15} /></button>
                <button className="ps-ledger-del" onClick={() => onDeleteItem(meal.id, it.id)}><Trash2 size={15} /></button>
              </>
            )}
          </li>
        ))}
      </ul>
      <div className="ps-total-row" style={{ marginTop: 10 }}>
        <span className="ps-total-label" style={{ fontSize: 13 }}>รวมมื้อนี้</span>
        <span className="ps-mono" style={{ fontWeight: 700 }}>฿{fmt(mealTotal)}</span>
      </div>

      {!readOnly && (mode === "addItem" || mode === "editItem") && (
        <div style={{ marginTop: 12, borderTop: "1px dashed var(--line)", paddingTop: 12 }}>
          <label className="ps-label">รายการ</label>
          <input className="ps-input" value={itemForm.desc} onChange={(e) => setItemForm((f) => ({ ...f, desc: e.target.value }))} placeholder="เช่น เหล้าขาว 1 แบน" />
          <label className="ps-label">จำนวนเงิน (฿)</label>
          <input className="ps-input" type="number" min="0" value={itemForm.amount} onChange={(e) => setItemForm((f) => ({ ...f, amount: e.target.value }))} />
          <label className="ps-label">ประเภท</label>
          <div className="ps-check-row">
            {CATS.map((c) => (
              <button key={c.v} type="button" className={`ps-check ${itemForm.category === c.v ? "on" : ""}`} onClick={() => setItemForm((f) => ({ ...f, category: c.v }))}>{itemForm.category === c.v && <Check size={12} />} {c.l}</button>
            ))}
          </div>
          <SplitPicker members={trip.members} selected={itemForm.splitAmong} toggle={toggle} />
          <PhotoField photo={itemForm.photo} onChange={(p) => setItemForm((f) => ({ ...f, photo: p }))} />
          <div className="ps-form-actions">
            <button className="ps-btn" disabled={!canSubmitItem} onClick={submitItem}><Plus size={14} /> {mode === "editItem" ? "บันทึกการแก้ไข" : "เพิ่มรายการ"}</button>
            <button className="ps-btn-ghost" onClick={cancelItemForm}>ยกเลิก</button>
          </div>
        </div>
      )}

      {!readOnly && mode === null && (
        <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
          <button className="ps-btn-ghost" onClick={startAddItem}><Plus size={13} /> เพิ่มรายการในมื้อนี้</button>
          <button className="ps-btn-ghost" onClick={() => onEditMeal(meal.id, { closed: true })}><Lock size={13} /> จบมื้อนี้</button>
        </div>
      )}
      {!tripReadOnly && meal.closed && (
        <button className="ps-btn-ghost" style={{ marginTop: 12 }} onClick={() => onEditMeal(meal.id, { closed: false })}><Unlock size={13} /> เปิดแก้ไขมื้อนี้</button>
      )}
    </TornCard>
  );
}

function ReportTab({ trip }) {
  const cat = tripCategoryTotals(trip);
  const grand = round2(cat.accommodation + cat.food + cat.beer + cat.liquor + cat.other);
  const breakdown = tripPersonBreakdown(trip);
  const net = computeBalancesFromEntries(trip.members, tripEntries(trip));
  const settlements = simplifyDebts(net);

  return (
    <div>
      <TornCard>
        <p className="ps-section-title"><BarChart3 size={14} /> สรุปยอดรวมทริป</p>
        <div className="ps-balance-row"><span><Bed size={12} style={{ verticalAlign: -1, marginRight: 4 }} />ค่าที่พัก</span><span className="ps-mono">฿{fmt(cat.accommodation)}</span></div>
        <div className="ps-balance-row"><span><span className="ps-cat-dot cat-food" />อาหาร</span><span className="ps-mono">฿{fmt(cat.food)}</span></div>
        <div className="ps-balance-row"><span><span className="ps-cat-dot cat-beer" />เบียร์</span><span className="ps-mono">฿{fmt(cat.beer)}</span></div>
        <div className="ps-balance-row"><span><span className="ps-cat-dot cat-liquor" />เหล้า</span><span className="ps-mono">฿{fmt(cat.liquor)}</span></div>
        {cat.other > 0 && <div className="ps-balance-row"><span><span className="ps-cat-dot cat-other" />อื่นๆ</span><span className="ps-mono">฿{fmt(cat.other)}</span></div>}
        <div className="ps-total-row"><span className="ps-total-label">รวมทั้งทริป</span><span className="ps-mono ps-total-amt">฿{fmt(grand)}</span></div>
      </TornCard>

      <TornCard>
        <p className="ps-section-title"><Users size={14} /> รายงานแยกรายคน</p>
        {trip.members.map((m) => {
          const b = breakdown[m];
          const shareTotal = round2(b.accommodation + b.food + b.beer + b.liquor + b.other);
          const v = net[m] || 0;
          const cls = v > 0.01 ? "pos" : v < -0.01 ? "neg" : "zero";
          return (
            <div key={m} style={{ borderBottom: "1px dashed var(--line)", padding: "10px 0" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 14 }}>
                <span>{m}</span>
                <span className={`ps-mono ps-balance-amt ${cls}`}>{v > 0.01 ? "ได้คืน " : v < -0.01 ? "ต้องจ่าย " : ""}฿{fmt(Math.abs(v))}</span>
              </div>
              <div className="ps-ledger-meta" style={{ marginTop: 4 }}>
                ใช้ไปทั้งหมด ฿{fmt(shareTotal)} (ที่พัก ฿{fmt(b.accommodation)} · อาหาร ฿{fmt(b.food)} · เบียร์ ฿{fmt(b.beer)} · เหล้า ฿{fmt(b.liquor)}) · จ่ายไปจริง ฿{fmt(b.paid)}
              </div>
            </div>
          );
        })}
      </TornCard>

      <TornCard>
        <p className="ps-section-title">ควรโอนเงินยังไง</p>
        {settlements.length === 0 ? (
          <div className="ps-stamp"><b>ลงตัวแล้ว ✓</b></div>
        ) : (
          settlements.map((s, i) => (
            <div className="ps-settle-item" key={i}><b>{s.from}</b><ArrowRight size={14} color="var(--ink-soft)" /><b>{s.to}</b><span className="ps-mono ps-settle-amt">฿{fmt(s.amount)}</span></div>
          ))
        )}
      </TornCard>
    </div>
  );
}

// ================= PARTY (also used for saved quick-splits) =================
function NewPartyForm({ title, hint, onCancel, onCreate }) {
  const [name, setName] = useState("");
  const [date, setDate] = useState("");
  const [members, setMembers] = useState([]);
  const canCreate = name.trim() && members.length >= 2;

  return (
    <div>
      <div className="ps-backrow"><button className="ps-iconbtn" onClick={onCancel}><ArrowLeft size={20} /></button><span style={{ fontWeight: 700 }}>{title}</span></div>
      <TornCard>
        <label className="ps-label">ชื่องาน</label>
        <input className="ps-input" placeholder={hint} value={name} onChange={(e) => setName(e.target.value)} />
        <label className="ps-label">วันที่ (ไม่บังคับ)</label>
        <input className="ps-input" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <label className="ps-label">สมาชิก (อย่างน้อย 2 คน)</label>
        <MemberChipInput members={members} setMembers={setMembers} />
        <div className="ps-form-actions">
          <button className="ps-btn" disabled={!canCreate} onClick={() => onCreate(name.trim(), date, members)}><Check size={15} /> สร้าง</button>
          <button className="ps-btn-ghost" onClick={onCancel}>ยกเลิก</button>
        </div>
      </TornCard>
    </div>
  );
}

function PartyDetail({ party, onBack, onUpdate, onDelete, onClearPhotos }) {
  const readOnly = !!party.closed;
  const emptyForm = () => ({ desc: "", amount: "", paidBy: party.members[0], splitAmong: party.members, photo: null });
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm());

  const total = partyTotal(party);
  const net = computeBalancesFromEntries(party.members, party.expenses);
  const settlements = simplifyDebts(net);
  const toggle = (m) => setForm((f) => ({ ...f, splitAmong: f.splitAmong.includes(m) ? f.splitAmong.filter((x) => x !== m) : [...f.splitAmong, m] }));
  const canSubmit = form.desc.trim() && Number(form.amount) > 0 && form.splitAmong.length > 0;
  const label = party.kind === "quick" ? "แชร์ด่วน" : "ปาร์ตี้";
  const photoCount = party.expenses.filter((e) => e.photo).length;

  const startEdit = (e) => { setEditingId(e.id); setForm({ desc: e.desc, amount: String(e.amount), paidBy: e.paidBy, splitAmong: e.splitAmong, photo: e.photo || null }); };
  const cancelEdit = () => { setEditingId(null); setForm(emptyForm()); };
  const submit = () => {
    const payload = { desc: form.desc.trim(), amount: round2(Number(form.amount)), paidBy: form.paidBy, splitAmong: form.splitAmong, photo: form.photo };
    if (editingId) onUpdate((p) => ({ ...p, expenses: p.expenses.map((e) => (e.id === editingId ? { ...e, ...payload } : e)) }));
    else onUpdate((p) => ({ ...p, expenses: [{ id: uid("exp"), ...payload }, ...p.expenses] }));
    cancelEdit();
  };
  const deleteExpense = (id) => onUpdate((p) => ({ ...p, expenses: p.expenses.filter((e) => e.id !== id) }));

  return (
    <div>
      <div className="ps-backrow">
        <button className="ps-iconbtn" onClick={onBack}><ArrowLeft size={20} /></button>
        <span style={{ fontWeight: 700, flex: 1 }}>{party.name} <span className="ps-kind-badge kind-party" style={{ marginLeft: 8 }}>{label}</span></span>
        <button className="ps-btn-ghost" onClick={() => onUpdate((p) => ({ ...p, closed: !p.closed }))}>{party.closed ? <><Unlock size={13} /> เปิดแก้ไข</> : <><Lock size={13} /> จบปาร์ตี้</>}</button>
        {photoCount > 0 && (
          <button className="ps-btn-ghost" onClick={onClearPhotos} title="ลบรูปใบเสร็จทั้งหมดในนี้ (เก็บรายการไว้)">
            <Camera size={13} /> ลบรูป ({photoCount})
          </button>
        )}
        <button className="ps-btn-ghost ps-btn-danger" onClick={onDelete}><Trash2 size={13} /> ลบ</button>
      </div>
      <div className="ps-members-strip"><Users size={13} /> {party.members.join(" · ")}{party.date ? ` · ${fmtDate(party.date)}` : ""}</div>

      {readOnly && <ClosedBanner label={`ปิด${label}นี้แล้ว`} onReopen={() => onUpdate((p) => ({ ...p, closed: false }))} />}

      {!readOnly && (
        <TornCard>
          <p className="ps-section-title"><Plus size={14} /> {editingId ? "แก้ไขรายการ" : "เพิ่มรายการค่าใช้จ่าย"}</p>
          <label className="ps-label">รายการ</label>
          <input className="ps-input" placeholder="เช่น ค่าอาหารเย็น, ค่าเซเว่น" value={form.desc} onChange={(e) => setForm((f) => ({ ...f, desc: e.target.value }))} />
          <label className="ps-label">จำนวนเงิน (฿)</label>
          <input className="ps-input" type="number" min="0" value={form.amount} onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))} />
          <label className="ps-label">ใครจ่าย</label>
          <p className="ps-hint">แต่ละรายการเลือกคนจ่ายแยกกันได้ ไม่จำเป็นต้องเป็นคนเดียวกันทุกรายการ เช่น รายการนี้ A จ่ายร้านอาหาร แต่รายการค่าเซเว่นให้ B จ่ายก็เลือก B ได้เลย</p>
          <select className="ps-select" value={form.paidBy} onChange={(e) => setForm((f) => ({ ...f, paidBy: e.target.value }))}>
            {party.members.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
          <SplitPicker members={party.members} selected={form.splitAmong} toggle={toggle} />
          <PhotoField photo={form.photo} onChange={(p) => setForm((f) => ({ ...f, photo: p }))} />
          <div className="ps-form-actions">
            <button className="ps-btn" disabled={!canSubmit} onClick={submit}><Plus size={15} /> {editingId ? "บันทึกการแก้ไข" : "เพิ่มรายการ"}</button>
            {editingId && <button className="ps-btn-ghost" onClick={cancelEdit}>ยกเลิก</button>}
          </div>
        </TornCard>
      )}

      <TornCard>
        <p className="ps-section-title"><Receipt size={14} /> รายการทั้งหมด ({party.expenses.length})</p>
        {party.expenses.length === 0 ? (
          <p style={{ color: "var(--ink-soft)", fontSize: 13 }}>ยังไม่มีรายการ</p>
        ) : (
          <ul className="ps-ledger">
            {party.expenses.map((e) => (
              <li key={e.id}>
                <PhotoThumbSmall photo={e.photo} />
                <div style={{ flex: 1 }}><div className="ps-ledger-desc">{e.desc}</div><div className="ps-ledger-meta">{e.paidBy} จ่าย · หาร {e.splitAmong.length} คน</div></div>
                <span className="ps-mono ps-ledger-amt">฿{fmt(e.amount)}</span>
                {!readOnly && (
                  <>
                    <button className="ps-ledger-del" onClick={() => startEdit(e)}><Pencil size={15} /></button>
                    <button className="ps-ledger-del" onClick={() => deleteExpense(e.id)}><Trash2 size={15} /></button>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
        <div className="ps-total-row"><span className="ps-total-label">รวมทั้งหมด</span><span className="ps-mono ps-total-amt">฿{fmt(total)}</span></div>
      </TornCard>

      <TornCard>
        <p className="ps-section-title"><Wallet size={14} /> สรุปยอดแต่ละคน</p>
        {party.members.map((m) => {
          const v = net[m] || 0;
          const cls = v > 0.01 ? "pos" : v < -0.01 ? "neg" : "zero";
          return <div className="ps-balance-row" key={m}><span>{m}</span><span className={`ps-mono ps-balance-amt ${cls}`}>{v > 0.01 ? "ได้คืน " : v < -0.01 ? "ต้องจ่าย " : ""}฿{fmt(Math.abs(v))}</span></div>;
        })}
        <p className="ps-section-title" style={{ marginTop: 18 }}>ควรโอนเงินยังไง</p>
        {settlements.length === 0 ? (
          <div className="ps-stamp"><b>ลงตัวแล้ว ✓</b></div>
        ) : (
          settlements.map((s, i) => <div className="ps-settle-item" key={i}><b>{s.from}</b><ArrowRight size={14} color="var(--ink-soft)" /><b>{s.to}</b><span className="ps-mono ps-settle-amt">฿{fmt(s.amount)}</span></div>)
        )}
      </TornCard>
    </div>
  );
}

// ================= STYLE =================
function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=IBM+Plex+Sans+Thai:wght@400;500;600;700&display=swap');

      .ps-app {
        --paper: #F1F3EE; --paper-dark: #E7EBDF; --ink: #1E2A26; --ink-soft: #5B685F;
        --jade: #1F6F54; --jade-dark: #164F3D; --jade-tint: #DCEAE2;
        --brick: #B8352E; --brick-tint: #F5DEDB; --gold: #A6791F; --gold-tint: #F0E4C6;
        --line: #C9D0BE;
        font-family: 'IBM Plex Sans Thai', 'Inter', system-ui, sans-serif;
        background: var(--paper); color: var(--ink); min-height: 100%;
        padding: 20px 16px 60px; box-sizing: border-box;
      }
      .ps-app * { box-sizing: border-box; }
      .ps-mono { font-family: 'JetBrains Mono', monospace; }
      .ps-shell { max-width: 680px; margin: 0 auto; }

      .ps-header { display:flex; align-items:flex-start; justify-content:space-between; margin-bottom: 20px; gap: 10px; }
      .ps-title { font-size: 24px; font-weight: 700; letter-spacing: -0.02em; margin: 0; }
      .ps-title-th { font-size: 15px; font-weight: 500; color: var(--ink-soft); margin-left: 6px; }
      .ps-subtitle { font-size: 13px; color: var(--ink-soft); margin: 4px 0 0; }
      .ps-reset-btn { background:none; border:1px solid var(--line); color: var(--ink-soft); border-radius: 8px; padding: 6px 8px; cursor:pointer; display:flex; align-items:center; gap:4px; font-size: 12px; white-space:nowrap; height: fit-content; }
      .ps-reset-btn:hover { border-color: var(--brick); color: var(--brick); }

      .ps-create-grid { display:grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 20px; }
      @media (max-width: 480px) { .ps-create-grid { grid-template-columns: 1fr; } }
      .ps-create-card { background: var(--jade); color:#fff; border:none; border-radius: 10px; padding: 16px 14px; display:flex; flex-direction:column; align-items:flex-start; gap: 4px; cursor:pointer; text-align:left; }
      .ps-create-card:nth-child(2) { background: var(--gold); }
      .ps-create-card span { font-weight: 700; font-size: 14px; margin-top: 2px; }
      .ps-create-card small { font-size: 11px; opacity: 0.9; }

      .ps-storage-box { margin-bottom: 14px; }
      .ps-storage-row { display:flex; align-items:center; justify-content:space-between; gap: 8px; font-size: 11px; color: var(--ink-soft); margin-bottom: 5px; flex-wrap: wrap; }
      .ps-storage-clear { background:none; border:1px solid var(--line); color: var(--ink-soft); border-radius: 999px; padding: 3px 9px; font-size: 11px; cursor:pointer; display:inline-flex; align-items:center; gap:4px; }
      .ps-storage-clear:hover { border-color: var(--brick); color: var(--brick); }
      .ps-storage-bar { height: 5px; background: var(--paper-dark); border-radius: 999px; overflow:hidden; border: 1px solid var(--line); }
      .ps-storage-fill { height: 100%; background: var(--jade); border-radius: 999px; transition: width .2s ease; }
      .ps-storage-fill.warn { background: var(--gold); }
      .ps-storage-fill.danger { background: var(--brick); }

      .ps-search-wrap { position:relative; margin-bottom: 18px; }
      .ps-search-icon { position:absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--ink-soft); }
      .ps-search-input { padding-left: 34px; }

      .ps-card { background: var(--paper-dark); border: 1px solid var(--line); border-bottom: none; border-radius: 10px 10px 0 0; position: relative; margin-bottom: 22px; }
      .ps-card-body { padding: 18px 18px 16px; }
      .ps-torn { height: 10px; background: linear-gradient(135deg, var(--paper) 50%, transparent 50%), linear-gradient(-135deg, var(--paper) 50%, transparent 50%); background-size: 14px 14px; background-repeat: repeat-x; background-position: bottom left; }

      .ps-grid { display:grid; grid-template-columns: 1fr; gap: 0; }
      @media (min-width: 560px) { .ps-grid { grid-template-columns: 1fr 1fr; gap: 16px; } }
      .ps-trip-card { cursor:pointer; transition: transform .12s ease; }
      .ps-trip-card:hover { transform: translateY(-2px); }
      .ps-kind-badge { display:inline-block; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 999px; margin-bottom: 6px; }
      .kind-trip { background: var(--jade-tint); color: var(--jade-dark); }
      .kind-party { background: var(--gold-tint); color: var(--gold); }
      .kind-quick { background: var(--brick-tint); color: var(--brick); }
      .ps-trip-name { font-size: 17px; font-weight: 700; margin: 0 0 2px; }
      .ps-trip-meta { font-size: 12px; color: var(--ink-soft); margin: 0 0 4px; }
      .ps-trip-total-row { display:flex; align-items:baseline; justify-content:space-between; margin-top: 10px; }
      .ps-trip-total { font-size: 20px; font-weight: 700; }
      .ps-badge { font-size: 11px; padding: 3px 8px; border-radius: 999px; font-weight: 600; }
      .ps-badge.settled { background: var(--jade-tint); color: var(--jade-dark); }
      .ps-badge.pending { background: var(--brick-tint); color: var(--brick); }
      .ps-badge.closed { background: var(--line); color: var(--ink-soft); }

      .ps-empty { text-align:center; padding: 30px 20px; color: var(--ink-soft); font-size: 13px; }

      .ps-btn { background: var(--jade); color: #fff; border:none; border-radius: 8px; padding: 10px 16px; font-weight: 600; font-size: 14px; cursor:pointer; display:inline-flex; align-items:center; gap: 6px; }
      .ps-btn:hover { background: var(--jade-dark); }
      .ps-btn:disabled { background: var(--line); color: var(--ink-soft); cursor:not-allowed; }
      .ps-btn-ghost { background:none; border:1px solid var(--line); color: var(--ink); border-radius: 8px; padding: 8px 12px; font-size:13px; cursor:pointer; display:inline-flex; align-items:center; gap:6px; white-space:nowrap; }
      .ps-btn-ghost:hover { border-color: var(--ink); }
      .ps-btn-danger { color: var(--brick); border-color: var(--brick-tint); }
      .ps-btn-danger:hover { border-color: var(--brick); }

      .ps-backrow { display:flex; align-items:center; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; }
      .ps-iconbtn { background:none; border:none; cursor:pointer; color: var(--ink); padding:4px; display:flex; }

      .ps-label { font-size: 12px; font-weight:600; color: var(--ink-soft); display:block; margin: 14px 0 6px; }
      .ps-hint { font-size: 11px; color: var(--ink-soft); margin: -3px 0 6px; line-height: 1.5; }
      .ps-input, .ps-select { width:100%; border: 1px solid var(--line); background: var(--paper); border-radius: 8px; padding: 10px 12px; font-size: 14px; color: var(--ink); font-family: inherit; }
      .ps-input:focus, .ps-select:focus { outline: 2px solid var(--jade); outline-offset: 1px; }

      .ps-chip-row { display:flex; flex-wrap:wrap; gap: 8px; margin-top: 8px; }
      .ps-chip { background: var(--jade-tint); color: var(--jade-dark); border-radius: 999px; padding: 6px 10px 6px 12px; font-size: 13px; display:flex; align-items:center; gap:6px; }
      .ps-chip button { background:none; border:none; cursor:pointer; color: var(--jade-dark); display:flex; }

      .ps-check-row { display:flex; flex-wrap:wrap; gap: 8px; margin-top: 6px; }
      .ps-check { border: 1px solid var(--line); border-radius: 999px; padding: 6px 12px; font-size: 13px; cursor:pointer; display:flex; align-items:center; gap: 6px; background: var(--paper); }
      .ps-check.on { background: var(--jade); color:#fff; border-color: var(--jade); }

      .ps-members-strip { display:flex; align-items:center; gap:6px; flex-wrap:wrap; margin-bottom: 4px; color: var(--ink-soft); font-size: 13px; }

      .ps-closed-banner { display:flex; align-items:center; justify-content:space-between; gap: 10px; flex-wrap: wrap; background: var(--paper-dark); border: 1px dashed var(--line); border-radius: 8px; padding: 10px 12px; font-size: 12px; color: var(--ink-soft); margin: 10px 0 4px; }

      .ps-tabs { display:flex; gap: 6px; margin: 16px 0; }
      .ps-tab { flex:1; background: var(--paper-dark); border: 1px solid var(--line); border-radius: 8px; padding: 9px 8px; font-size: 12px; font-weight:600; color: var(--ink-soft); cursor:pointer; display:flex; align-items:center; justify-content:center; gap: 5px; }
      .ps-tab.on { background: var(--jade); color:#fff; border-color: var(--jade); }

      .ps-ledger { list-style:none; margin: 8px 0 0; padding: 0; }
      .ps-ledger li { display:flex; align-items:center; padding: 10px 0; border-bottom: 1px dashed var(--line); font-size: 14px; gap: 10px; }
      .ps-ledger li:last-child { border-bottom: none; }
      .ps-ledger-desc { font-weight: 600; }
      .ps-ledger-meta { font-size: 12px; color: var(--ink-soft); }
      .ps-ledger-amt { font-weight: 700; white-space:nowrap; }
      .ps-ledger-del { background:none; border:none; color: var(--ink-soft); cursor:pointer; padding:4px; display:flex; }
      .ps-ledger-del:hover { color: var(--brick); }

      .ps-cat-tag { font-size: 10px; font-weight: 700; padding: 1px 6px; border-radius: 999px; margin-left: 6px; }
      .cat-food { background: var(--jade-tint); color: var(--jade-dark); }
      .cat-beer { background: var(--gold-tint); color: var(--gold); }
      .cat-liquor { background: var(--brick-tint); color: var(--brick); }
      .cat-other { background: var(--line); color: var(--ink-soft); }
      .ps-cat-dot { display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:6px; vertical-align:1px; }
      .ps-cat-dot.cat-food { background: var(--jade); }
      .ps-cat-dot.cat-beer { background: var(--gold); }
      .ps-cat-dot.cat-liquor { background: var(--brick); }
      .ps-cat-dot.cat-other { background: var(--ink-soft); }

      .ps-total-row { display:flex; justify-content:space-between; align-items:baseline; margin-top: 14px; padding-top: 12px; border-top: 2px solid var(--ink); }
      .ps-total-label { font-weight: 700; }
      .ps-total-amt { font-size: 22px; font-weight: 700; }

      .ps-balance-row { display:flex; justify-content:space-between; align-items:center; padding: 8px 0; font-size: 14px; }
      .ps-balance-amt.pos { color: var(--jade-dark); font-weight:700; }
      .ps-balance-amt.neg { color: var(--brick); font-weight:700; }
      .ps-balance-amt.zero { color: var(--ink-soft); font-weight:700; }

      .ps-settle-item { display:flex; align-items:center; gap: 10px; padding: 10px 12px; background: var(--paper); border: 1px solid var(--line); border-radius: 8px; margin-bottom: 8px; font-size: 14px; }
      .ps-settle-amt { margin-left:auto; font-weight:700; color: var(--gold); }

      .ps-section-title { font-size: 14px; font-weight: 700; margin: 0 0 10px; display:flex; align-items:center; gap:6px; }
      .ps-form-actions { display:flex; gap: 10px; margin-top: 16px; flex-wrap: wrap; }
      .ps-stamp { text-align:center; padding: 18px 0; color: var(--jade-dark); }
      .ps-stamp b { display:inline-block; font-size: 15px; border: 2px solid var(--jade); padding: 6px 16px; border-radius: 6px; transform: rotate(-2deg); }

      .ps-photo-add { display:inline-flex; align-items:center; gap: 6px; border: 1px dashed var(--line); border-radius: 8px; padding: 8px 12px; font-size: 12px; color: var(--ink-soft); cursor:pointer; }
      .ps-photo-add:hover { border-color: var(--jade); color: var(--jade); }
      .ps-photo-row { display:flex; align-items:center; gap: 10px; }
      .ps-photo-thumb { width: 56px; height: 56px; object-fit: cover; border-radius: 8px; border: 1px solid var(--line); cursor: pointer; }
      .ps-photo-thumb-sm { width: 36px; height: 36px; object-fit: cover; border-radius: 6px; border: 1px solid var(--line); cursor: pointer; flex-shrink: 0; }
      .ps-photo-overlay { position: fixed; inset: 0; background: rgba(20,26,23,0.85); display:flex; align-items:center; justify-content:center; z-index: 1000; padding: 24px; cursor: zoom-out; }
      .ps-photo-overlay img { max-width: 100%; max-height: 100%; border-radius: 8px; }
    `}</style>
  );
}
